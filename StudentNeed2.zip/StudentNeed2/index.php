<?php
error_reporting(E_ALL & ~E_NOTICE);
 include 'include/action_log.php';
 include 'language/lang.php';
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Home Page</title>
  <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->
  <link rel="stylesheet" type="text/css" href="mycss/style.css">
  <script type="text/javascript" src="jquery/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

<!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
      .nav-link{
        color: black;
      }
      .nav-item a:hover{
        color: #007bff;

      }
      .navbar-brand{
        font-size: 1.5rem; 
        margin: 1.7;
        margin-left: 70px;
      }

      html {
       font-family: "Josefin Sans", sans-serif; 
       font-size: 16px;
       }
     
      .bg-img {
        /* The image used */
        /*background-image: url("images/background.jpg");*/

        min-height: 710px;
        width: 100%;
        height:100%;
        /* Center and scale the image nicely */
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
      }

      .container{
          font-family: 'Josefin Sans', sans-serif;
          max-width: 1200px;
      }

      h1{
          /*font-family: 'Josefin Sans', sans-serif;*/
          font-weight: 700;
          font-size: 4.60rem;
          /*margin: 1.7rem;*/
          color: #000;
      }
      h4{
       
         font-weight: 700;
          font-size: medium;
          letter-spacing: 0.12rem;
          color: #000;
      }

      .lg {
        position: relative;
        margin: auto;
        max-width: 300px;
        padding: 16px;
        background-color: #c0c0c0;
        border-radius: 30px;
       
      }

      .vertical-center {
        margin: 0;
        position: absolute;
        top: 50%;
        left: 50%;
        -ms-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
      }

      .intro{
          display: flex;
          flex-wrap: wrap;
          text-align: center;
        }

      .home{ 
        width: 100%; 
        height: 100vh;
        background-color: #fff; 
        display: flex;
        flex-direction: column;
       }

       .navbar-brand:hover{
        color: black;
       }

  </style>
</head>
<body style="background-color: #fff; ">
  <section class="home">
  <nav class="navbar navbar-expand-sm navbar-dark sticky-top" style="background-color: #fff">
    <div class="d-flex align-items-center justify-content-between">
      <a href="#" class="logo d-flex align-items-center">
        <img src="assets/img/logo_org.png" alt="">
        <span>STUDENT</span>
        <span style="color: aquamarine;">NEED</span>
      </a>
    </div><!-- End Logo -->
        <!-- <a class="navbar-brand" href="#" style="color: black;">STUDENT<span>NEED</span></a> -->

          <button class="navbar-toggler" type="button" data-toggle="collapse" 
         data-target="#collapsibleNavbar" aria-controls="collapsibleNavbar" 
         aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="nav nav-pills">
            <li class="nav-item ">
              <a class="nav-link" href="index.php" id="indhome"><?php echo lang('home');?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#about" id="Aboutlink"><?php echo 'About';?></a>
            </li> 
            <li class="nav-item">
              <a class="nav-link" href="#" id="Services"><?php echo 'Services';?></a>
             </li>
             <li class="nav-item"> 
              <a class="nav-link" href="#" id="Contact"><?php echo 'Contact us';?></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><?php echo lang('language'); ?></a>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id="" href="index.php?language=english"><?php echo lang('english'); ?></a>
                  <a class="dropdown-item" id="" href="index.php?language=english"><?php echo lang('arabic'); ?></a></div>
            </li>
          </ul>
        </div>
      </nav>
    <div>
      <?php 
                $query= "SELECT ads_id, photo_path, description FROM `ads` WHERE confirmed = 1 AND cancel <> 1
                         ORDER BY create_date LIMIT 5";
                $statment=$conn->prepare($query);
                $statment->execute();
                $adsResult=$statment->get_result();
                $adsRows=$adsResult->fetch_all();
                $rowsCount = count($adsRows);

                if ( $rowsCount > 0) {  
                  $activeIndex = 0;
               ?>
              <!-- Slides with captions -->
              <div  id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                  <?php while ($activeIndex < $rowsCount) {
                    ?>
                    <button hidden type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo $activeIndex; ?>" class="<?php if ($activeIndex == 0) echo 'active';?>" aria-current="true" aria-label="Slide <?php echo $activeIndex+1; ?>"></button>
                  <?php
                      $activeIndex = $activeIndex + 1; 
                   } ?>
                </div>
                <div class="carousel-inner">
                  <?php
                    $activeIndex = 0;
                    while ($activeIndex < $rowsCount) { ?>
                  <div  class="carousel-item <?php if ($activeIndex == 0) echo 'active';?>">
                    <img src="<?php echo $adsRows[$activeIndex][1]; ?>" class="bg-img" alt="..." style="width:100%;height:42px;border:0;opacity: 0.8;">
                    <div class="carousel-caption d-none d-md-block">
                      <!-- <h5>First slide label</h5> -->
                      <p><?php echo $adsRows[$activeIndex][2]; ?></p>
                    </div>
                  </div>
                <?php
                    $activeIndex = $activeIndex + 1;
                 } ?>
                </div>

              </div><!-- End Slides with captions -->
            <?php } ?>
      <div class="container vertical-center" >
        <div class="row">
          <div class="col-md-8" style="margin-bottom: 60px;">
            <div class="intro">
            <h1>welcome <samp>students</samp></h1>
            <h4>we are  here to help you for what you need</h4>
          </div>
        </div>
        <div class="col-md-4">
            <div class="lg">
              <div>
                <h2><?php echo 'Login';?></h2>
                <p> <?php echo lang('pfiyctl');?></p>
              </div>

              <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"  method="post">
                <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                  <label><?php echo lang('username');?></label>
                  <input type="text" placeholder="<?php echo lang('enter user');?>" name="username" class="form-control" value="<?php echo $username; ?>">
                  <span class="help-block" style="color:red;"><?php echo $username_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                  <label><?php echo lang('password');?></label>
                  <input type="password" placeholder="<?php echo lang('enter pass');?>" name="password" class="form-control">
                  <span class="help-block" style="color:red;"><?php echo $password_err; ?></span>
                </div>
                <div>
                  <span class="help-block" style="color:red;"><?php echo $error; ?></span>
                </div>
                <div>
                  <input type="submit" class="btn btn-primary " name="login" style="width: 100%" value=" <?php echo lang('login');?> ">
                  <a class="help-block" href="#" onclick="" style="font-size:14px;font-weight: 700;"><?php echo lang('passwordForget');?></a>
                </div>
              </form>
            </div>

        </div>
        </div>
      </div>
    </div>
    <div id="about" class="container" style="margin-top: 100px; " >
        <div class="row">
        <!--   <div class="col-md-4" style="margin-bottom: 60px;">
            
          </div> -->
          <div class="col-md-12" style="margin-bottom: 60px;text-align: center; padding: 0 90px;">
            <div class="">
              <h1 style="margin-bottom: 20px; ">About</h1>
              <h4 style="    font-size: 20px;
              line-height: 30px;
              color: #23242a;">Student needs are deficiencies in specific skills that impede academic, physical, behavioral, and self-help activities in daily living or social achievement.  Student Need aims to provide an educational environment characterized by empathy and respect for those who suffer from these challenges in our society, and it is a website that contains all the tools and purposes that students need for their studies, this website to provide their needs, information and help students who may face challenges or concerns about basic needs.</h4>
            </div>
        </div>
      </div>
    </div>
    <?php   
        include 'footer.php';
     ?>
  </section>
    
</body>
</html>