<?php
include 'include/action.php';
include 'language/lang.php'; 
// Check if the user is logged in, if not then redirect him to error page
if((!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) && (!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true)){
header("location: error.php");
exit;
}

$query= "SELECT (@row_number:=@row_number + 1) AS row_num, file_id,file_name, path, extension, description,  c.cat_name, create_user, f.create_date, is_url, url, confirme_date, u.user_name FROM files f, categories c, users u, (SELECT @row_number:=0) AS temp 
WHERE f.cat_id = c.cat_id AND f.create_user = u.user_id AND confirmed = 0 ORDER BY f.create_date DESC";
$statment=$conn->prepare($query);
$statment->execute();
$filesResult=$statment->get_result();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Comatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="" name="description">
        <meta content="" name="keywords">

        <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="mycss/style.css">
        <script type="text/javascript" src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Favicons -->
        <link href="assets/img/logo.png" rel="icon">
    
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
        <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
       
        <title>Files Management</title>

    </head>
    <body class="">
         <?php 
        include "include/nav.php";
        ;?> 
        <main id="main" class="main">
            <div class="d-flex align-items-center">
                <div class="pagetitle">
                    <h1>Files Management</h1>
                    <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashborad.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Files Management</li>
                    </ol>
                  </nav>
                </div><!-- End Page Title -->
            </div>
        

        <div id="begin_load" style="min-height: 455px;">
            <div class="col-12">
                <div class="card overflow-auto">
                <div class="card-body">
                  <h5 class="card-title"> Uploads Pending List</h5>

                  <!-- Table with stripped rows -->
                  <table class="table table-striped datatable">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">File Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Category</th>
                        <th scope="col">Type</th>
                        <th scope="col">Create User</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php while ($filesRows=$filesResult->fetch_assoc()) {
                        $file_type = 'OTHERS';
                        if (!empty(trim(fType($filesRows['extension'])))){
                          $file_type = fType($filesRows['extension']);
                        }
                        echo '<tr>';
                        echo '<th scope="row">'.$filesRows['row_num'].'</th>';
                        echo '<td class="text-break"><a href="file_details.php?file_id='.$filesRows['file_id'].'">'.ucwords(strtolower($filesRows['file_name'])).'</a></td>';
                        echo '<td class="text-break">'.ucwords(strtolower($filesRows['description'])).'</td>';
                        echo '<td class="text-break">'.ucwords(strtolower($filesRows['cat_name'])).'</td>';
                        echo '<td>'.ucwords(strtolower($file_type)).'</td>';
                        echo '<td class="text-break">'.ucwords(strtolower($filesRows['user_name'])).'</td>';
                        echo '<td>
                            <a href="include/action.php?confirmFile='.$filesRows['file_id'].'" class="badge badge-success p-2">confirm</a>
                            <a href="include/action.php?rejectFile='.$filesRows['file_id'].'" class="badge badge-danger p-2">reject</a>
                          </td>';
                        echo '</tr>';
                    } ?>
                    </tbody>
                  </table>
                  <!-- End Table with stripped rows -->
                </div>
              </div>
          </div>
        </div>
    </main>

    <?php 
        include 'footer.php';
     ?>
     
    </body>

</html>