<?php
include 'include/config.php';
// Resume the session
session_start();

session_unset();
 
// Destroy the session (clear session file from server).
session_destroy();
 
// Redirect to login page
header("location: index.php");
exit;
?>