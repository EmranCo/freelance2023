<?php 
function lang($phrase){
	$lang=array(
		'home'=>'Home',
		'system'=>'System',
		'account'=>'Accounts',
		'data'=>'Data',
		'report'=>'Reports',
		'card_no'=>'Card_NO',
		'park_no'=>'Parking_NO'
	);
	return $lang[$phrase];

}
?>