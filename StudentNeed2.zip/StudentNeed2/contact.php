<?php
include 'include/action.php';
include 'language/lang.php'; 
// Check if the user is logged in, if not then redirect him to error page
if((!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) && (!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true)){
header("location: error.php");
exit;
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Comatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="" name="description">
        <meta content="" name="keywords">

        <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="mycss/style.css">
        <script type="text/javascript" src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Favicons -->
        <link href="assets/img/logo.png" rel="icon">
    
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
        <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
       
        <title>Contact Us</title>

    </head>
    <body class="">
         <?php 
        include "include/nav.php";
        ;?> 
        <main id="main" class="main">
            <div class="d-flex align-items-center">
            <div class="pagetitle">
                <h1>Contact</h1>
                <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashborad.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Contact</li>
                </ol>
              </nav>
            </div><!-- End Page Title -->
            </div>
        

        <div id="begin_load" style="min-height: 455px;">
            
        </div>
    </main>

    <?php 
        include 'footer.php';
     ?>
     
    </body>

</html>