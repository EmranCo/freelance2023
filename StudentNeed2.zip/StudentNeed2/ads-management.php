<?php
include 'include/action.php';
include 'language/lang.php'; 
// Check if the user is logged in, if not then redirect him to error page
if((!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) && (!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true)){
header("location: error.php");
exit;
}

$query= "SELECT (@row_number:=@row_number + 1) AS row_num, ads_id, u.user_name, description, photo_path, create_user, a.create_date, confirmed, confirme_date FROM ads a, users u, (SELECT @row_number:=0) AS temp WHERE a.create_user = u.user_id AND confirmed = 0 ORDER BY create_date DESC";
$statment=$conn->prepare($query);
$statment->execute();
$adsResult=$statment->get_result();



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Comatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="" name="description">
        <meta content="" name="keywords">

        <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="mycss/style.css">
        <script type="text/javascript" src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Favicons -->
        <link href="assets/img/logo.png" rel="icon">
    
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
        <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
       
        <title>Ads Management</title>

    </head>
    <body class="">
         <?php 
        include "include/nav.php";
        ;?> 
        <main id="main" class="main">
            <div class="d-flex align-items-center">
            <div class="pagetitle">
                <h1>Ads Management</h1>
                <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashborad.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Ads Management</li>
                </ol>
              </nav>
            </div><!-- End Page Title -->
            </div>       

        <div id="begin_load" style="min-height: 455px;">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title"> Ads Pending List</h5>

              <!-- Table with stripped rows -->
              <table class="table table-striped datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Description</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Create User</th>
                    <th scope="col">Create Date</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php while ($adsRows=$adsResult->fetch_assoc()) {
                    echo '<tr>';
                    echo '<th scope="row">'.$adsRows['row_num'].'</th>';
                    echo '<td>'.ucwords(strtolower($adsRows['description'])).'</td>';
                    echo '<td>'.ucwords(strtolower($adsRows['photo_path'])).'</td>';
                    echo '<td>'.ucwords(strtolower($adsRows['user_name'])).'</td>';
                    echo '<td>'.ucwords(strtolower($adsRows['create_date'])).'</td>';
                    echo '<td>
                            <a href="include/action.php?confirmAds='.$adsRows['ads_id'].'" class="badge badge-success p-2">confirm</a>
                            <a href="include/action.php?rejectAds='.$adsRows['ads_id'].'" class="badge badge-danger p-2">reject</a>
                          </td>';
                    echo '</tr>';
                } ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
            </div>
          </div>
        </div>
    </main>

    <?php 
        include 'footer.php';
     ?>
     
    </body>

</html>