<?php  
if(!isset($_SESSION)){
session_start();}


	if(isset($_GET['language'])){
		$_SESSION['returnlang']=$_GET['language'];
		header('location:'.$_SERVER['PHP_SELF']);

	}
	
	switch($_SESSION['returnlang']){
		case "english":require_once 'english.php';
		break;
		case "arabic":require_once 'arabic.php';
		break;
		default:require_once 'english.php';
		break;

	}


?>