<!DOCTYPE html>
<html lang="en">
<head >
 <meta charset="utf-8">
 <title></title>
 <style type="text/css">
  body{
   direction: rtl;
  }
  .dropdown-menu.show{
   text-align: right;
  }
  .form-group{
   text-align: right;
  }
  h1,h2,h3,h4,h5,p{
   text-align: right;
  }
 </style>
</head>
<body>
 <?php 
function lang($phrase){
 $lang=array(
  'home'=>'الصفحة اﻟﺮﺋﻴﺴﻴﺔ',
  'help'=>'ﻣﺴﺎﻋﺪﺓ',
  'cust_site'=>'ﻣﻮﻗﻊ اﻟﺰﺑﺎﺋﻦ',
  'system'=>'اﻟﻨﻈﺎﻡ',
  'account'=>'اﻟﺤﺴﺎﺑﺎﺕ',
  'data'=>'اﻟﺒﻴﺎﻧﺎﺕ',
  'report'=>'اﻟﺘﻘﺎﺭﻳﺮ',
  'card_no'=>'ﺭﻗﻢ اﻟﺒﻄﺎﻗﺔ',
  'search'=>'ﺑﺤﺚ',
  'chpass'=>'ﺗﻐﻴﺮ ﻛﻠﻤﺔ اﻟﺴﺮ',
  'logout'=>'ﺧﺮﻭﺝ',
  'een'=>'اﺩﺧﻞ ﺭﻗﻢ الموظف',
  'park lots'=>'اﻟﻤﻮاﻗﻒ',
  'sensor stat'=>'ﺣﺎﻟﺔ اﻟﺤﺴﺎﺱ',
  'lots stat'=>'ﺣﺎﻟﺔ اﻟﻤﻮﻗﻒ',
  'taken'=>'ﻣﺸﻐﻮﻝ',
  'empty'=>'ﻓﺎﺿﻲ',
  'error'=>'!ﺧﻄﺄ',
  'normal'=>'ﻃﺒﻴﻌﻲ',
  'enter time'=>' ﻭﻗﺖ اﻟﺪﺧﻮﻝ',
  'action'=>'',
  'detail'=>'اﻟﺘﻔﺎﺻﻴﻞ',
  'parked'=>'ااﻟﻤﺸﻐﻮﻝ',
  'available'=>'اﻟﻤﺘﻮﻓﺮ',
  'language'=>'اﻟﻠﻐﺔ',
  'english'=>'اﻻﻧﺠﻠﻴﺰﻳﺔ',
  'arabic'=>'اﻟﻌﺮﺑﻴﺔ',
  'contact us'=>' اﺗﺼﻞ ﺑﻨﺎ',
  'about'=>'ﻋﻨﺎ',
  'wt'=>'ﻣﺮﺣﺒﺎ ﺑﻚ ﻓﻲ',
  'sys_name'=> 'نظام تتبع الموظفين',
  'syattts'=>'ﺣﺪﺩ ﻧﻮﻉ ﺩﺧﻮﻟﻚ اﻟﻰ اﻟﻤﻮﻗﻊ',
  'user login'=>'ﺩﺧﻮﻝ اﻟﻤﺴﺘﺨﺪﻡ',
  'pfiyctl'=>'ﻳﺮﺟﻰ ﻣﻞء اﻟﺒﻴﺎﻧﺎﺕ ﻟﻠﺪﺧﻮﻝ',
  'username'=>'اﺳﻢ اﻟﻤﺴﺘﺨﺪﻡ',
  'password'=>'ﻛﻠﻤﺔ اﻟﻤﺮﻭﺭ',
  'enter user'=>'اﺩﺧﻞ اﺳﻢ اﻟﻤﺴﺘﺨﺪﻡ',
  'login'=> 'تسجيل الدخول',
  'enter pass'=>'اﺩﺧﻞ ﻛﻠﻤﺔ اﻟﻤﺮﻭﺭ',
  'login as'=>'اﻟﺪﺧﻮﻝ ﻙ  :',
  'user'=>'ﻣﻮﻇﻒ',
  'admin'=>'ﻣﺪﻳﺮ',
  'add user'=>'اﺿﺎﻓﺔ ﻣﻮﻇﻒ',
  'add admin'=>'اﺿﺎﻓﺔ ﻣﺪﻳﺮ',
  'user list'=>'ﻗﺎﺋﻤﺔ اﻟﻤﻮﻇﻔﻴﻦ',
  'data storage'=>'البيانات المخزنة',
  'accessinfo'=>'ﻣﻌﻠﻮﻣﺎﺕ اﻟﺪﺧﻮﻝ',
  'restrict data'=>'اﻟﺒﻴﺎﻧﺎﺕ اﻟﻤﻘﻴﺪﺓ',
  'cards'=>'اﻟﺒﻄﺎﺋﻖ',
  'sign up'=>'اضافة حساب',
  'pftftaaua'=>'الرجاء ملء الأتي لأضافة موظف',
  'conpass'=>'ﺗﺄﻛﻴﺪ ﻛﻠﻤﺔ اﻟﻤﺮﻭﺭ',
  'submit'=>'تأكيد',
  'reset'=>'ﺗﺠﺎﻫﻞ',
  'pftftaaaa'=>'اﻟﺮﺟﺎء ﻣﻞء اﻷﺗﻲ ﻷﺿﺎﻓﺔ ﻣﺪﻳﺮ',
  'employee list'=>'ﻗﺎﺋﻤﺔ اﻟﻤﻮﻇﻔﻴﻦ',
  'UserName'=>'اﺳﻢ اﻟﻤﻮﻇﻒ',
  'created at'=>'ﺗﺎﺭﻳﺦ اﻷﺿﺎﻓﺔ',
  'created by'=>'ﺃﺿﻴﻒ ﺑﻮاﺳﻄﺔ',
  'grade'=>'اﻟﺪﺭﺟﺔ',
  'add card'=>'اضافة بطاقة',
  'enter card id'=>' ادخل رمز البطاقة  :',
  'enter card no'=>' ادخل رقم البطاقة  :',
  'get card'=>'قراءة البطاقة ',
  'add'=>'اضافة',
  'card info'=>'البطائق',
  'card id'=>'كود البطاقة',
  'card no'=>'رقم البطاقة',
  'defined at'=>'تاريخ التعريف',
  'delete'=>'حذف',
  'alarm info'=>'الأنذارات',
  'id'=>'الرقم',
  'caused by'=>'السبب',
  'customer info'=>'معلومات الزبائن',
  'exit time'=>'وقت الخروج ',
  'parking time'=>'مدة الوقوف',
  'price'=>'التكلفة',
  'eainfo'=>'معلومات دخول الموظفين',
  'no'=>'الرقم',
  'bdreport'=>'الفترة المطلوبة',
  'from date'=>'من تاريخ  :',
  'to date'=>' الى تاريخ  :',
  'cinfofrom'=>'معلومات الزبائن من',
  'total price'=>'الاجمالي المستلم  :',
  'to'=>'الى',
  'employees'=>'الموظفين',
  'users'=>'المستخدمين',
  'passwordForget'=>'هل نسيت كلمة المرور؟',
  'searchparam'=>'Search Parameters',
	'emp_id'=>'رقم الموظف',
	'emp_name'=>'اسم الموظف',
	'department'=>'القسم',
	'emp_log'=>'حركات الموظف',
	'status'=>'الحالة',
	'Valid'=>'فعال',
	'Not Valid'=>'غير فعال',
	'Set Valid'=>'الى فعال',
	'Set Not Valid'=>'الى غير فعال',
	'scan'=>'افحص البطاقة',
	'stop scan'=>'توقيف الفحص',
	'Add Department'=>'اضافة قسم جديد',
	'Department Information'=> 'معلومات الأقسام',
	'Department'=>'الأقسام',
	'Department Id'=>'رقم القسم',
	'Department Name'=>'اسم القسم',
	'Section'=>'الفرع',
	'Add'=>'إضافة',
	'Cancel'=>'الغاء',
	'Update'=>'تحديث',
	'Add Employee'=>'اضافة موظف جديد',
	'emp id'=>'رقم الموظف',
	'C_status'=>'حالة البطاقة',
	'Hire Date'=>'تاريخ التوظيف',
	'User Id'=>'رقم المستخدم',
	'User Type'=>'صلاحية المستخدم',
	'Cr_User'=>'المنشئ',
	'Cr_Date'=>'تاريخ الانشاء',
	'Cr Date'=>'تاريخ الانشاء',
	'Add User'=>'إضافة مستخدم جديد',
	'User Information'=>'معلومات المستخدم',
	'Reset Password'=>'اعادة تعيين كلمة المرور',
	"Employee's Information"=>"معلومات الموظفين",
	'Location'=>'الموقع',
	'Outside'=>'خارج',
	'Inside'=>'داخل',
  ''=>'',
  ''=>'',
 );
 return $lang[$phrase];

}
?>

</body>
</html>
