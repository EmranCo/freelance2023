<script>
function datafilter() {

  var input, filter, table, tr, td, i, txtValue,firstCol ,secondCol, thirdCol,firstColTextValue ,secondColTextValue, thirdColTextValue;
 var input1 = document.getElementById('deptIdInput');
 var input2 = document.getElementById('deptNameInput');
 var input3 = document.getElementById('deptSection');

 var filter1 = input1.value.toUpperCase();
 var filter2 = input2.value.toUpperCase();
 var filter3 = input3.value.toUpperCase();

  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  for (i = 0; i < tr.length; i++) {
    firstCol = tr[i].getElementsByTagName("td")[0];
    secondCol = tr[i].getElementsByTagName("td")[1];
    thirdCol = tr[i].getElementsByTagName("td")[2];


    if(firstCol || secondCol || thirdCol ){
      firstColTextValue  = firstCol.textContent;
      secondColTextValue = secondCol.textContent;
      thirdColTextValue = thirdCol.textContent;

      if (firstColTextValue.toUpperCase().indexOf(filter1) > -1 && secondColTextValue.toUpperCase().indexOf(filter2) > -1 && thirdColTextValue.toUpperCase().indexOf(filter3) > -1) {
              tr[i].style.display = "";
      } else {
          tr[i].style.display = "none";
      }           
    }
  }
}
</script>

<?php
include 'include/action.php';
include 'include/config.php';
include 'language/lang.php';

// Initialize the session
if(!isset($_SESSION)){
session_start();}
 
// Check if the Admin is logged in, if not then redirect him to error page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: error.php");
    exit;
}

$query= "SELECT * FROM departments";
$statment=$conn->prepare($query);
$statment->execute();
$deptResult=$statment->get_result();
$deptRows=$deptResult->fetch_all();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Departments</title>
  <style >
    #department{
      border-radius: .25rem;
      background-color: #007bff;
        }
    #department a{
        color: white;
     }
    table thead {
      background-color: #007bff;
     color: white;}
     table tbody{
      background-color: #d6e7ef54;
     }
      td span{
      color: red;
     }
      td span span{
      color: blue;
     }
     td span.stat1{
      color: green;
     }
     td span.stat2{
      color: #d20c0cc2;
     }
  </style>
</head>

<body>
  <nav>
    <?php include "include/nav.php";?>
  </nav>  



<!-- Modal -->
<div class="modal fade" id="DepartmentModalId" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">  <?php echo lang('Add Department'); ?> </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
          <div class="form-group">
            <input type="text" style="display: none;" id="NewDeptId" name="NewDeptId" >
            <h6><?php echo lang('Department Name');?></h6>
            <input type="text" class="form-control" id="NewDeptName" name="NewDeptName"  placeholder="Enter department name.." value="<?php echo $NewDeptName; ?>">
          </div>    
        <div class="form-group">
           <h6><?php echo lang('Section');?></h6>
           <input type="text" class="form-control" id="NewDeptSection" name="NewDeptSection" placeholder="Enter department section.." value="<?php echo $NewDeptSection; ?>">
        </div>
               
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"> <?php echo lang('Cancel') ?> </button>
        <input type="submit" id="departmentButton" class="btn btn-primary" name="deptButton" style="width: 100%" value="<?php echo lang('Add') ?>">
      </div>
    </div>
  </div>
</div>



 	<div class="container-fluid">
          <div class="row justify-content-center">
              <div class="col-md-4">
                    <h3 class="text-center text-dark m-2"><?php echo lang('search');?></h3>
                    <hr>
                    <div class="col-mid-4 ">
                      <div class="card">
                        <div class="card-header">
                          <strong><?php echo lang('searchparam');?></strong>
                        </div>
                          <div class="card-body card-block">
                            <h6><?php echo lang('Department Id');?></h6>
                            <input type="text" class="form-control" id="deptIdInput" onkeyup="datafilter()" placeholder="Search by department id..">
                            <br>
                            <h6><?php echo lang('Department Name');?></h6>
                            <select class="form-control" class="form-control" id="deptNameInput" onchange="datafilter()" onkeyup="datafilter()">
                              <option value="" selected>-All Departments-</option>
                              <?php foreach($deptRows as $key => $deptRow) { ?>
                                 <option value="<?php echo $deptRow[1]; ?>"> <?php echo $deptRow[1] ?></option>
                              <?php  } ?>
                            </select>
                            <br>
                            <h6><?php echo lang('Section');?></h6>
                            <input type="text" class="form-control" id="deptSection" onkeyup="datafilter()" placeholder="Search by section..">
                          </div>
                          <hr>
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-success" data-toggle="modal" data-target="#DepartmentModalId">
                            <?php echo '+'.lang('Add Department'); ?>
                          </button>
                        </div>

                    </div>
               </div>
               
               <div class="col-md-8">
                <br>
                <?php
                  if ($_SESSION['error'] == 1){
                    ?>
                    <div class="alert alert-danger" role="alert">
                      <?php  echo $_SESSION['errorMessage'];?>
                    </div>
                    <?php  
                  }
                     $_SESSION['error'] = 0;   
                    ?>

                    <h3 class="text-center  text-info"><?php echo lang('Department')?></h3>
                    <table id="myTable" class="table  table-hover">
                        <thead>
                          <tr>
                            <th><?php echo lang('Department Id')?></th>
                            <th><?php echo lang('Department Name')?></th>
                            <th><?php echo lang('Section')?></th>
                            <th><?php echo lang('action')?></th>
                          </tr>
                        </thead>
                        <tbody>
                         <?php foreach($deptRows as $key => $row) { ?>
                          <tr>
                            <td><?= $row[0]; ?></td>
                            <td><?= $row[1]; ?></td>
                            <td><?= $row[2]; ?></td>
                            <td>
                               <a href="#" class="badge badge-info p-2" data-toggle="modal" data-target="#DepartmentModalId"
                                data-deptid="<?php echo($row[0]); ?>"
                                data-deptname="<?php echo($row[1]); ?>"
                                data-deptsection="<?php echo($row[2]); ?>" ><?php echo lang('detail')?></a>
                               <a href="include/actionbtn.php?deleteDeptId=<?= $row[0];?>" class="badge badge-danger p-2"><?php echo lang('delete') ?></a>
                            </td>
                          </tr>
                         <?php }?>
                        </tbody>
                      </table>
               </div>
          </div>
     </div>
     <script>
        $('#DepartmentModalId').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var vdeptid = button.data('deptid') // Extract info from data-* attributes
        var vdeptname = button.data('deptname')
        var vsection = button.data('deptsection')


        var modal = $(this)
        if (button.data('deptid')) {
          modal.find('.modal-title').text('<?php echo lang('Department Information') ?>')
          modal.find('#NewDeptId').val(vdeptid)
          modal.find('#NewDeptName').val(vdeptname)
          modal.find('#NewDeptSection').val(vsection)
          document.getElementById("departmentButton").className = "btn btn-primary"
          document.getElementById("departmentButton").value = "<?php echo lang('Update') ?>"
          

        }
        else {
          modal.find('.modal-title').text('<?php echo lang('Add Department') ?>')
          modal.find('#NewDeptId').val('')
          modal.find('#NewDeptName').val('')
          modal.find('#NewDeptSection').val('')
          document.getElementById("departmentButton").className = "btn btn-success";
          document.getElementById("departmentButton").value = "<?php echo lang('Add') ?>"

        }



      })
      </script>
</body>

</html>
