<?php
include 'include/action.php';
include 'language/lang.php'; 
// Check if the user is logged in, if not then redirect him to error page
if((!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) && (!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true)){
header("location: error.php");
exit;
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Comatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="" name="description">
        <meta content="" name="keywords">

        <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="mycss/style.css">
        <script type="text/javascript" src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Favicons -->
        <link href="assets/img/logo.png" rel="icon">
    
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
        <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">

        <style type="text/css">
            .col-12{
                padding: 0;
            }
            .form-group .form-text-label{
                margin: 10px 0 0 0;
            }
            .check-card{
                border: 1px solid #ced4da;
                margin-top: 15px;
                border-radius: 5px;
                background-color: #efefef;
                padding-bottom: 15px;
            }
        </style>

        <title>Users Management</title>

    </head>
    <body class="">
         <?php 
        include "include/nav.php";

        $usrType = array(
            1 => 'Admin',
            2 => 'Student'
        );
           

        $query= "SELECT * FROM users";
        $statment=$conn->prepare($query);
        $statment->execute();
        $userResult=$statment->get_result();    

        ;?> 
        <main id="main" class="main">
            <div class="d-flex align-items-center">
            <div class="pagetitle">
                <h1>Users Management</h1>
                <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashborad.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Users Management</li>
                </ol>
              </nav>
            </div><!-- End Page Title -->
            <div class="ms-auto">
                <?php 
                if ($_SESSION['user_type'] == 1) {
                    echo '<button type="button" class="btn btn-success" data-toggle="modal" data-target="#UsersModalId">+ New User</button>';
                }else{
                    echo '<button type="button" disabled class="btn btn-secondary">+ New User</button>';
                } ?>
            </div>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="UsersModalId" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">  Add New User </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <input type="text" style="display: none;" id="NewUserId" name="NewUserId" >
                            <label class="form-text-label">User Name</label>
                            <input type="text" class="form-control" id="NewUserName" name="NewUserName"  placeholder="Enter user name.." value>
                            <label class="form-text-label">User Full Name</label>
                            <input type="text" class="form-control" id="NewFullName" name="NewFullName"  placeholder="Enter user full name.." value>
                            <label class="form-text-label"><?php echo lang('User Type');?></label>
                            <select class="form-select" id="NewUserType" name="NewUserType">
                              <option value selected disabled>-Select a User Type-</option>
                              <?php foreach ($usrType as $key => $value) { ?>
                                 <option value="<?php echo $key; ?>"> <?php echo $value; ?></option>
                              <?php  } ?>
                            </select>

                            <div class="col-sm-12 check-card">
                                <label class="form-text-label" style="font-weight: bold;">User Privileges</label>
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" id="UploadPrivilege" name="UploadPrivilege">
                                  <label class="form-check-label" for="UploadPrivilege">
                                    Upload Files
                                  </label>
                                </div>

                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" id="AdsPrivileage" name="AdsPrivileage">
                                  <label class="form-check-label" for="AdsPrivileage">
                                    Create Ads
                                  </label>
                                </div>
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" id="LoginPrivilege" name="LoginPrivilege">
                                  <label class="form-check-label" for="LoginPrivilege">
                                    System Login
                                  </label>
                                </div>

                              </div>
                        </div>
                        <div class="input-group-append">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" style="margin-right: 10px;"> <?php echo lang('Cancel') ?> </button>
                            <input type="submit" id="userButton" class="btn btn-success" name="userButton" style="width: 100%" value="<?php echo 'Add' ?>">
                        </div>
                     </form>      
                  </div>
                </div>
              </div>
            </div>
        

        <div id="begin_load" style="min-height: 455px;">
            <div class="col-12">
                <div class="card overflow-auto">
                <div class="card-body">
                  <h5 class="card-title"> Users List</h5>

                  <!-- Table with stripped rows -->
                  <table class="table table-striped datatable">
                    <thead>
                      <tr>
                        <th scope="col">User Id</th>
                        <th scope="col">User Name</th>
                        <th scope="col">User Type</th>
                        <th scope="col">Create User</th>
                        <th scope="col">Create Date</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php while ($userRows=$userResult->fetch_assoc()) {

                        $query= "SELECT user_name FROM users where user_id = ?";
                        $statment=$conn->prepare($query);
                        $statment->bind_param("i",$userRows['createdUser']);
                        $statment->execute();
                        $cr_userResult=$statment->get_result(); 
                        $cr_userRows=$cr_userResult->fetch_assoc();

                        $Status = '<span class="badge badge-success">active</span>';
                        if($userRows['cancel']==1){
                            $Status = '<span class="badge badge-danger">canceled</span>';
                        }
                           
                        echo '<tr>';
                        echo '<th scope="row">'.$userRows['user_id'].'</th>';
                        echo '<td>'.$userRows['user_name'].'</td>';
                        echo '<td>'.$usrType[$userRows['user_type']].'</td>';
                        echo '<td>'.$cr_userRows['user_name'].'</td>';
                        echo '<td>'.$userRows['createdDate'].'</td>';
                        echo '<td>'.$Status.'</td>';
                        echo '<td>
                            <a href="#" class="badge badge-primary p-2" style="margin-bottom: 2px;" data-toggle="modal" data-target="#UsersModalId"
                            data-userid="'.$userRows['user_id'].'"
                            data-username="'.$userRows['user_name'].'"
                            data-fullname="'.$userRows['name'].'"
                            data-usertype="'.$userRows['user_type'].'"
                            data-uploadpriv="'.$userRows['uploadPrivilege'].'"
                            data-adspriv="'.$userRows['createAdsPrivilege'].'"
                            data-loginpriv="'.$userRows['cancel'].'" >details</a>
                            <a href="include/action.php?deleteUser='.$userRows['user_id'].'" class="badge badge-danger p-2">delete</a>
                          </td>';
                        echo '</tr>';
                    } ?>
                    </tbody>
                  </table>
                  <!-- End Table with stripped rows -->
                </div>
              </div>
          </div>
            
        </div>
    </main>

    <?php 
        include 'footer.php';
     ?>

     <script>
        $('#UsersModalId').on('show.bs.modal', function (event) {

        var button = $(event.relatedTarget)
        var vuserid = button.data('userid')
        var vusername = button.data('username')
        var vfullname = button.data('fullname')
        var vusertype = button.data('usertype')
        var vuploadpriv = button.data('uploadpriv')
        var vadspriv = button.data('adspriv')
        var vloginpriv = button.data('loginpriv')

        var modal = $(this)
        if (button.data('userid')) {
          modal.find('.modal-title').text('Update User')
          modal.find('#NewUserId').val(vuserid)
          modal.find('#NewUserName').val(vusername)
          modal.find('#NewFullName').val(vfullname)
          modal.find('#NewUserType').val(vusertype)
          if (vuploadpriv ==1){
            document.getElementById("UploadPrivilege").checked = 'on'
          }else{
            document.getElementById("UploadPrivilege").checked = ''
          }
          if (vadspriv ==1){
            document.getElementById("AdsPrivileage").checked = 'on'
          }else{
            document.getElementById("AdsPrivileage").checked = ''
          }
          if (vloginpriv == 0){
            document.getElementById("LoginPrivilege").checked = 'on'
          }else{
            document.getElementById("LoginPrivilege").checked = ''
          }
          document.getElementById("userButton").className = "btn btn-primary"
          document.getElementById("userButton").value = "<?php echo lang('Update') ?>"
          

        }else {
          modal.find('.modal-title').text('Add New User')
          modal.find('#NewUserId').val('')
          modal.find('#NewUserName').val('')
          modal.find('#NewFullName').val('')
          modal.find('#NewUserType').val(2)
          document.getElementById("UploadPrivilege").checked = ''
          document.getElementById("AdsPrivileage").checked = ''
          document.getElementById("LoginPrivilege").checked = 'on'
          document.getElementById("userButton").className = "btn btn-success";
          document.getElementById("userButton").value = "<?php echo lang('Add') ?>"
        }
      })
      </script>
     
    </body>

</html>