<?php
include 'include/action.php';
include 'language/lang.php'; 
// Check if the user is logged in, if not then redirect him to error page
if((!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) && (!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true)){
header("location: error.php");
exit;
}

$user_id = $_SESSION['user_id'];

$query= "SELECT (@row_number:=@row_number + 1) AS row_num, f.*, c.cat_name, d.create_date download_date FROM downloads d, files f, categories c, (SELECT @row_number:=0) AS temp where d.file_id = f.file_id and f.cat_id= c.cat_id and user_id = ? and f.cancel <> 1 and confirmed=1 ORDER by d.create_date DESC";
$statment=$conn->prepare($query);
$statment->bind_param('i', $user_id);
$statment->execute();
$downResult=$statment->get_result();




?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Comatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="" name="description">
        <meta content="" name="keywords">

        <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="mycss/style.css">
        <script type="text/javascript" src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Favicons -->
        <link href="assets/img/logo.png" rel="icon">
    
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
        <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
       
        <title>Main Page</title>

    </head>
    <body class="">
         <?php 
        include "include/nav.php";
        ;?> 
        <main id="main" class="main">
            <div class="d-flex align-items-center">
            <div class="pagetitle">
                <h1>Downloads</h1>
                <nav style="--bs-breadcrumb-divider: '>';">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Downloads</li>
                </ol>
              </nav>
            </div><!-- End Page Title -->
            <div class="ms-auto">
           <!--  <div class="d-block d-lg-none">
              <a class="nav-link nav-icon search-bar-toggle " href="#" style="font-size: 22px;">
                <i class="bi bi-search"></i>
              </a>
            </div> -->
            <!-- End Search Icon-->
            <!-- <div class="search-bar">
              <form class="search-form d-flex align-items-center" method="POST" action="#">
                <input type="text" name="query" placeholder="Search" title="Enter search keyword">
                <button type="submit" title="Search"><i class="bi bi-search"></i></button>
              </form>
            </div> -->
            <!-- End Search Bar -->
            </div>
            </div>
        

        <div id="begin_load" style="min-height: 455px;">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">My Downloads List</h5>

              <!-- Table with stripped rows -->
              <table class="table table-striped datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">File Name</th>
                    <th scope="col">File Description</th>
                    <th scope="col">Category</th>
                    <th scope="col">Type</th>
                    <th scope="col">Path</th>
                    <th scope="col">Download Date</th>
                  </tr>
                </thead>
                <tbody>
                <?php while ($downRows=$downResult->fetch_assoc()) {
                    $file_type = 'OTHERS';
                    if (!empty(trim(fType($downRows['extension'])))){
                      $file_type = fType($downRows['extension']);
                    }
                    echo '<tr>';
                    echo '<th scope="row">'.$downRows['row_num'].'</th>';
                    echo '<td>'.ucwords(strtolower($downRows['file_name'])).'</td>';
                    echo '<td>'.ucwords(strtolower($downRows['description'])).'</td>';
                    echo '<td>'.ucwords(strtolower($downRows['cat_name'])).'</td>';
                    echo '<td>'.ucwords(strtolower($file_type)).'</td>';
                    echo '<td><a href="file_details.php?file_id='.$downRows['file_id'].'">'.$downRows['path'].'</a></td>';
                    echo '<td>'.$downRows['download_date'].'</td>';
                    echo '</tr>';
                } ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
            </div>
          </div>
        </div>
    </main>

    <?php 
        include 'footer.php';
     ?>
     
    </body>

</html>