<?php
include 'include/action.php';
include 'language/lang.php'; 
// Check if the user is logged in, if not then redirect him to error page
if((!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) && (!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true)){
header("location: error.php");
exit;
}

$user_id = $_SESSION['user_id'];

$query= "SELECT (@row_number:=@row_number + 1) AS row_num, a.* FROM
(SELECT NULL ads_id, description, NULL photo_path, create_user, create_date, confirmed, request_date FROM rejects WHERE reject_type = 2 and create_user = ?
UNION ALL
SELECT  ads_id, description, photo_path, create_user, create_date, confirmed, confirme_date FROM ads WHERE create_user = ?) a, (SELECT @row_number:=0) AS temp
ORDER BY confirmed, a.create_date DESC";
$statment=$conn->prepare($query);
$statment->bind_param('ii', $user_id,$user_id);
$statment->execute();
$adsResult=$statment->get_result();




?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Comatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="" name="description">
        <meta content="" name="keywords">

        <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="mycss/style.css">
        <script type="text/javascript" src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Favicons -->
        <link href="assets/img/logo.png" rel="icon">
    
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
        <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
        <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
        <style type="text/css">
            .form-group label{
                margin: 10px 0 0 0;
            }

        </style>
       
        <title>My Ads</title>
    </head>
    <body class="">
         <?php 
        include "include/nav.php";
        ;?> 
        <main id="main" class="main">
            <div class="d-flex align-items-center">
                <div class="pagetitle">
                    <h1>Ads</h1>
                    <nav style="--bs-breadcrumb-divider: '>';">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Ads</li>
                    </ol>
                  </nav>
                </div><!-- End Page Title -->
                <div class="ms-auto">
                    <?php 
                    if ($_SESSION['createAdsPrivilege'] == 1) {
                        echo '<button type="button" class="btn btn-success" data-toggle="modal" data-target="#AdsModalId">+ New Ads</button>';
                    }else{
                        echo '<button type="button" disabled class="btn btn-secondary">+ New Ads</button>';
                    } ?>
                </div>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="AdsModalId" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">  Add New Ads </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="subject" class="">Upload Ads Photo</label>
                            <input class="form-control" type="file" name="adsPhoto">
                            <footer style="font-size: 12px"><b>Photo Type:</b><font color="red"><i>.jpg .icon .png .gif .bmp</i></font></footer>
                            <input type="text" style="display: none;" class="form-control" id="AdsId" name="AdsId">
                            <label>Ads Description</label>
                            <textarea type="textarea" class="form-control" id="AdsDesc" name="AdsDesc" placeholder="Write a description for your ads.." value style="height: 150px;"></textarea>
                        </div>
                        <div class="input-group-append">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" style="margin-right: 10px;"> <?php echo lang('Cancel') ?> </button>
                            <input type="submit" id="newAdsButton" class="btn btn-success" name="newAdsButton" style="width: 100%" value="<?php echo 'Save' ?>">
                        </div>
                     </form>      
                  </div>
                </div>
              </div>
            </div>
        

        <div id="begin_load" style="min-height: 455px;">
            <div class="card">
            <div class="card-body">
              <h5 class="card-title">My Ads List</h5>

              <!-- Table with stripped rows -->
              <table class="table table-striped datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Description</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Create Date</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                <?php while ($adsRows=$adsResult->fetch_assoc()) {
                    echo '<tr>';
                    echo '<th scope="row">'.$adsRows['row_num'].'</th>';
                    echo '<td>'.ucwords(strtolower($adsRows['description'])).'</td>';
                    echo '<td>'.ucwords(strtolower($adsRows['photo_path'])).'</td>';
                    echo '<td>'.ucwords(strtolower($adsRows['create_date'])).'</td>';
                    switch ($adsRows['confirmed']) {
                        case 0:
                            echo '<td><span class="badge bg-warning">Pendding</span></td>';
                            break;
                        case 1:
                            echo '<td><span class="badge bg-success">Approved</span></td>';
                            break;
                        default:
                            echo '<td><span class="badge bg-danger">Rejected</span></td>';
                            break;
                    }
                    
                    echo '</tr>';
                } ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
            </div>
          </div>
        </div>
    </main>

    <?php 
        include 'footer.php';
     ?>
     
    </body>

</html>