<?php 
error_reporting(E_ALL & ~E_NOTICE);

$host = "localhost";
$username="root";
$password="";
$database="studentNeeds";


$conn = new mysqli($host, $username,$password,$database);

if ($conn->connect_error) {
	die("Could not connect to the database!".$conn->connect_error);
}

?>
